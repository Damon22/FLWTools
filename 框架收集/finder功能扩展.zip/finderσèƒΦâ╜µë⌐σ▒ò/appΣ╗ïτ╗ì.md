1. 剪切： 将当前文件移动到某个文件夹  
2. addnewfile: 在当前文件夹中新建文件
3. cdtodir： 打开命今行，直接cd到当前目录
4. snipname：截图时同时给截图起个名字

用法：选中app， 按住 commond 拖动到 finder的工具栏中。 使用时，点击finder工具栏图标即可，或直接双击运行。